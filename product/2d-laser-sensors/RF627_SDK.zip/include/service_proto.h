#pragma once

#include <stdint.h>

#pragma pack(push,1)
typedef struct
{
    char        name[64];
    uint16_t    device_id;
    uint32_t    serial_number;
    uint32_t    firmware_version;
    uint32_t    hardware_version;
    uint32_t    config_version;
    uint32_t    fsbl_version;
    uint32_t    z_begin;
    uint32_t    z_range;
    uint32_t    x_smr;
    uint32_t    x_emr;
    uint8_t     reserved_0[36];

    uint16_t    eth_speed;
    uint32_t    ip_address;
    uint32_t    net_mask;
    uint32_t    gateway_ip;
    uint32_t    host_ip;
    uint16_t    stream_port;
    uint16_t    http_port;
    uint16_t    service_port;
    uint16_t    eip_broadcast_port;
    uint16_t    eip_port;
    uint8_t     hardware_address[6];
    uint8_t     reserved_1[26];

    uint32_t    max_payload_size;
    uint8_t     reserved_2[32];

    uint8_t     stream_enabled;
    uint8_t     stream_format;
    uint8_t     reserved_3[32];

    uint8_t     reserved_4[256];
}
rf627_device_info_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    char        name[64];
    uint8_t     save_log_to_spi;
    uint8_t		reserved[127];
}
rf627_general_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    int16_t		fpga_temp;
    uint8_t		params_changed;			//Параметры были изменены, но не сохранены: 1 - factory, 2 - user, 3 - factory & user
    int16_t		sens00_temp;
    int16_t		sens00_max;
    int16_t		sens00_min;
    int16_t		sens01_temp;
    int16_t		sens01_max;
    int16_t		sens01_min;
    int16_t		sens10_temp;
    int16_t		sens10_max;
    int16_t		sens10_min;
    int16_t		sens11_temp;
    int16_t		sens11_max;
    int16_t		sens11_min;
    uint8_t		reserved[55];
}rf627_sysmon_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t		dhs;
    uint8_t		gain_analog;
    uint8_t		gain_digital;
    uint32_t	exposure;
    uint32_t	max_exposure;
    uint32_t	frame_rate;
    uint32_t	max_frame_rate;
    uint8_t     exposure_hdr_mode;
    uint8_t     auto_exposure;
    uint8_t		column_edr_mode;
    uint8_t		column_exposure_div;
    uint8_t     column_exposure_max_div;
    uint8_t		reserved_1[59];
}rf627_sensor_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t		enable;
    uint16_t	tcp_port;
    uint8_t		reserved[32];
}rf627_rf625compat_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t		enable;
    uint8_t		active;
    uint16_t	window_height;
    uint8_t		position_mode;
    uint16_t	window_top;
    uint16_t	current_window_top;
    uint16_t	profile_size;
    uint8_t		reserved[80];
}rf627_roi_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint16_t	speed;
    uint8_t		autonegotiation;
    uint32_t    ip_address;
    uint32_t    net_mask;
    uint32_t    gateway_ip;
    uint32_t    host_ip;
    uint16_t    stream_port;
    uint16_t    http_port;
    uint16_t    service_port;
//    uint16_t    eip_broadcast_port;
//    uint16_t    eip_port;
    uint8_t		reserved[68];
}rf627_network_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t		enable;
    uint8_t		format;
    uint8_t		ack;
    uint8_t     include_intensivity;
    uint8_t		reserved[31];
}rf627_stream_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint32_t	brightness_threshold;
    uint8_t		filter_width;
    uint8_t		processing_mode;
    uint8_t		reduce_noise;
    uint32_t    frame_rate;
    uint8_t		median_filter_mode;
    uint8_t		bilateral_filter_mode;
    uint8_t     peak_select_mode;
    uint8_t     profile_flip;
    uint8_t		reserved[56];
}rf627_image_processing_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t		enable;
    uint8_t		auto_level;
    uint16_t	level;
    uint8_t		reserved[32];
}rf627_laser_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint16_t    params_mask;
    uint8_t		in1_enable;
    uint8_t		in1_mode;
    uint32_t	in1_delay;
    uint8_t		in1_decimation;
    uint8_t		in2_enable;
    uint8_t		in2_mode;
    uint8_t		in2_invert;
    uint8_t		in3_enable;
    uint8_t		in3_mode;
    uint8_t		reserved[12];
}rf627_inputs_preset_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t                 preset_index;
    rf627_inputs_preset_t   params[12];
    uint8_t                 reserved[32];
}rf627_inputs_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    uint8_t		out1_enable;
    uint8_t		out1_mode;
    uint32_t	out1_delay;
    uint32_t	out1_pulse_width;
    uint8_t		out1_invert;
    uint8_t		out2_enable;
    uint8_t		out2_mode;
    uint32_t	out2_delay;
    uint32_t	out2_pulse_width;
    uint8_t		out2_invert;
    uint8_t		reserved[32];
}rf627_outputs_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct
{
    rf627_general_params_t          general;
    rf627_sysmon_params_t           sysmon;
    rf627_rf625compat_params_t      rf625compat;
    rf627_sensor_params_t           sensor;
    rf627_roi_params_t              roi;
    rf627_network_params_t          network;
    rf627_stream_params_t           stream;
    rf627_image_processing_params_t image_processing;
    rf627_laser_params_t            laser;
    rf627_inputs_params_t           inputs;
    rf627_outputs_params_t          outputs;
    uint8_t                         reserved[283];
}rf627_user_params_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct{
                struct{
                        uint32_t                        H;
                        uint8_t                                M;
                        uint8_t                                S;
                }Time;
                uint8_t                                        ModuleID;
                uint8_t                                        EventID;
                char                                        String[128];
}rf627_log_record_t;
#pragma pack(pop)
