#pragma once

#include "service_proto.h"
#include "stream_proto.h"
#include <vector>
#include <memory>
#include <thread>
#include <mutex>
#include <functional>

#ifdef _WIN32
#include <winsock.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#define INVALID_SOCKET (-1)
#define NULL (0)
typedef int SOCKET;
#endif

#if (defined _WIN32 && defined RF627_LIBRARY)
#define RF627_API __declspec(dllexport)
#else
#define RF627_API
#endif

#if __cplusplus < 199711L
#ifndef nullptr
#define nullptr 0
#endif
#endif

/*! Structure to store a point of profile
 */
struct rf627_point
{
    float x;
    float z;
};

/*! Structure to store a profile
 */
struct rf627_profile
{
    rf627_stream_msg_t header;
    std::vector<rf627_point> points;
    std::vector<uint16_t> pixels;
    std::vector<uint8_t> intensity;
};

class rf627;
typedef std::vector<std::shared_ptr<rf627>> rf627_list;
typedef void (*rf627_data_proc)(rf627_profile profile);

class RF627_API rf627
{
public:
    /*! Initialize library
     * Must be called once before further calls to any library functions
     */
    static bool init();
    /*! Cleanup resources allocated with init() function
     */
    static void cleanup();
    /*! Return SDK version
     */
    static uint32_t version();

    /*! Search for RF627 devices over network
     * \param ok            :   ptr to boolean to indicate error
     * \return list of rf627 objects
     */
    static rf627_list search(bool *ok = nullptr);

    /*! Return const reference to structure containing device information
     */
    const rf627_device_info_t& info() const;

    /*! Establish connection to the device
     * \return true on success
     */
    bool connect();
    /*! Close connection to the device
     */
    void disconnect();

    /*! Read parameters from device to internal structure. This structure is accessible via params() function
     * \param pparams         :   ptr to rf627_user_params_t structure; if not null parameters will be copied to this struct
     * \return true on success
     */
    bool read_params(rf627_user_params_t* pparams = nullptr);
    /*! Write parameters to device's memory
     * \param pparams         :   ptr to rf627_user_params_t structure; if not null parameters will be copied from this struct before writing to device
     * \return true on success
     */
    bool write_params(rf627_user_params_t* pparams = nullptr);
    /*! Save parameters from device's memory to flash
     * \return true on success
     */
    bool flush_params();
    /*! Reset parameters to factory set
     * \return true on success
     */
    bool reset_params();
    /*! Reboot the device
     * \return true on success
     */
    bool reboot();

    /*! Read specific block of parameters from device to internal structure. This structure is accessible as params() substructure
     * \param pparams         :   ptr to rf627_xxx_params_t structure; if not null parameters will be copied to this struct
     * \return true on success
     */
    bool read_general_params(rf627_general_params_t* pparams = nullptr);
    bool read_sysmon_params(rf627_sysmon_params_t* pparams = nullptr);
    bool read_rf625compat_params(rf627_rf625compat_params_t* pparams = nullptr);
    bool read_sensor_params(rf627_sensor_params_t* pparams = nullptr);
    bool read_roi_params(rf627_roi_params_t* pparams = nullptr);
    bool read_network_params(rf627_network_params_t* pparams = nullptr);
    bool read_stream_params(rf627_stream_params_t* pparams = nullptr);
    bool read_image_processing_params(rf627_image_processing_params_t* pparams = nullptr);
    bool read_laser_params(rf627_laser_params_t* pparams = nullptr);
    bool read_inputs_params(rf627_inputs_params_t* pparams = nullptr);
    bool read_outputs_params(rf627_outputs_params_t* pparams = nullptr);

    /*! Write specific block of parameters to device's memory
     * \param pparams         :   ptr to rf627_xxx_params_t structure; if not null parameters will be copied from this struct before writing to device
     * \return true on success
     */
    bool write_general_params(rf627_general_params_t* pparams = nullptr);
    bool write_sysmon_params(rf627_sysmon_params_t* pparams = nullptr);
    bool write_rf625compat_params(rf627_rf625compat_params_t* pparams = nullptr);
    bool write_sensor_params(rf627_sensor_params_t* pparams = nullptr);
    bool write_roi_params(rf627_roi_params_t* pparams = nullptr);
    bool write_network_params(rf627_network_params_t* pparams = nullptr);
    bool write_stream_params(rf627_stream_params_t* pparams = nullptr);
    bool write_image_processing_params(rf627_image_processing_params_t* pparams = nullptr);
    bool write_laser_params(rf627_laser_params_t* pparams = nullptr);
    bool write_inputs_params(rf627_inputs_params_t* pparams = nullptr);
    bool write_outputs_params(rf627_outputs_params_t* pparams = nullptr);

    /*! Return ref to internal parameters structure
     */
    inline rf627_user_params_t &params() {return m_params;}

    /*! Get measurement from scanner's data stream
     * \param profile         :   ref to rf627_profile structure to be filled with measurement result
     * \return true on success
     */
    bool get_result(rf627_profile& profile);

    static void set_fixed_result_size(bool enable);

    /*! Read image from CMOS (each pixel is 8-bit value representing brightess in range of 0..255
     * \param ppixmap         :   a ptr to buffer to fill with image pixels; must be RF627_IMAGE_SIZE bytes
     * \return true on success
     */
    bool get_image(uint8_t* ppixmap);

    /*! Write firmware image file to device's memory
     * \param file_name         :   name of file to transfer (normally *.rf627)
     * \return true on success
     */
    bool write_firmware_image(const char* file_name);
    /*! Save firmware image from device's memory to flash. Do not call this function unless write_firmware_image() returns true!
     * \return true on success
     */
    bool flush_firmware_image();

    /*! Read log entries from the device
     * \param nstart_line      :   number of start line
     * \param plog_entries     :   array of rf627_log_record_t structs to store log lines read; array items count must be equal to nlines
     * \param nlines           :   number of lines to read; must be less or equal to RF627_MAX_LOG_ENTRIES_PER_PAYLOAD
     * \return true on success
     */
    bool read_log(uint32_t nstart_line, rf627_log_record_t *plog_entries, int nlines);
    /*! Get total log entries count
     * \return number of log entries; 0 on error
     */
    uint32_t read_log_record_count();

    /*! Get ptr to string containing the last error message
     */
    const char *error_msg();

    /*! Register udp callback function and start udp streaming in background
     * \param proc      :   ptr to callback function
     *                      callback function must be defined as void fn(rf627_profile profile)
     */
    void register_callback(rf627_data_proc proc, void *context = nullptr);
    /*! Unregister udp callback function and stop background thread
     */
    void unregister_callback();

    // Internal
#if __cplusplus >= 199711L
    rf627() = delete;
    rf627(const rf627&) = delete;
#endif
    rf627(rf627_device_info_t* info, uint16_t init_msg_count = 1);
    virtual ~rf627();

private:
#if __cplusplus < 199711L
    rf627() {}
    rf627(const rf627&) {}
#endif
    rf627_device_info_t m_info;
    rf627_user_params_t m_params;
    uint16_t m_msg_count;
    SOCKET m_svc_sock,
           m_data_sock;
    std::function<void(rf627_profile profile)> m_callback;
    std::thread* m_thread;
    u_long m_locif;
    void data_proc();
};
