#pragma once

#include <stdint.h>

typedef enum: uint8_t
{
    DTY_PixelsNormal        = 0x10,
    DTY_ProfileNormal       = 0x11,
    DTY_PixelsInterpolated  = 0x12,
    DTY_ProfileInterpolated = 0x13
} rf627_data_type_t;

#pragma pack(push,1)
typedef struct
{
    rf627_data_type_t data_type;
    uint8_t     flags;
    uint16_t    device_type;
    uint32_t    serial_number;
    uint64_t    system_time;

    uint8_t     proto_version_major;
    uint8_t     proto_version_minor;
    uint8_t     hardware_params_offset;
    uint8_t     data_offset;
    uint32_t    packet_count;
    uint32_t    measure_count;

    uint16_t    zmr;
    uint16_t    xemr;
    uint16_t    discrete_value;
    uint8_t     reserved_0[14];

    uint32_t    exposure_time;
    uint32_t    laser_value;
    uint32_t    step_count;
    uint8_t     dir;
    uint8_t     reserved_1[3];
}
rf627_stream_msg_t;
#pragma pack(pop)
