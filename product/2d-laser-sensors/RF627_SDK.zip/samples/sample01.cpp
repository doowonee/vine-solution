/* sample01.cpp
 *
 * Sample of use of rf627 SDK
 *
 * - Search RF627 scanners over network
 * - Connects to first found device if found
 * - Reads scanner settings and display scanner name
 * - Gets and displays measured profile if UDP streaming is enabled
 */

#include "include/rf627.h"
#include <iomanip>
#include <iostream>

void main()
{
    rf627::init();

    std::cout << "Searching..." << std::endl;
    bool ok;
    rf627_list dev_list = rf627::search(&ok);
    if (ok)
    {
        std::cout << "Found " << dev_list.size() << " devices" << std::endl;
        if (!dev_list.empty())
        {
            rf627* dev = dev_list.at(0).get();
            std::cout << "Connecting to first device..." << std::endl;
            if (dev->connect())
            {
                if (dev->read_params())
                {
                    std::cout << "Scanner name: " << dev->params().general.name << std::endl;
                    std::cout << "UDP streaming is enabled: ";
                    if (dev->params().stream.enable)
                    {
                        std::cout << "Yes" << std::endl;
                        rf627_profile profile;
                        if (dev->get_result(profile))
                        {
                            std::cout << "Read profile, " << profile.points.size() << " points:" << std::endl;
                            for (const rf627_point &point: profile.points)
                            {
                                std::cout << std::fixed << std::setprecision(3) << "[" << point.x << "," << point.z << "], ";
                            }
                            std::cout << std::endl;
                        }
                        else
                        {
                            std::cout << "Error getting profile: " << dev->error_msg() << std::endl;
                        }
                    }
                    else
                    {
                        std::cout << "No" << std::endl;
                    }
                }
                else
                {
                    std::cout << "Error reading parameters: " << dev->error_msg() << std::endl;
                }
                dev->disconnect();
            }
            else
            {
                std::cout << "Error: " << dev->error_msg() << std::endl;
            }
        }
    }
    else
    {
        std::cout << "Network error" << std::endl;
    }

    rf627::cleanup();
}
