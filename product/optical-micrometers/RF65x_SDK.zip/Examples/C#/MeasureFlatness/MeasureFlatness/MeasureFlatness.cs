﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Lasers;

namespace MeasureFlatness
{
    public partial class MeasureFlatness : Form
    {
        AR500[] sensors = new AR500[5];



        public MeasureFlatness()
        {
            InitializeComponent();

	    var init = RFDeviceObjectNet.Initialize();
	    if (init == 0)
	    {
		// Unable to initialize RFDevice
		return;
	    }

            // Initialize all of the lasers...

            string[] comPorts = { "Com1", "Com2", "Com3", "Com4", "Com5" };

            for (int i = 0; i < 5; ++i)
            {
                sensors[i] = new Lasers.AR500();
                sensors[i].Open(comPorts[i], 9600, 1);
            }
        }

        private void MeasureFlatness_Load(object sender, EventArgs e)
        {

            
        }

        private void ButtonGetReadings_Click(object sender, EventArgs e)
        {
            double reading;

            reading = sensors[0].GetReading();
            textBox1.Text = reading.ToString();

            reading = sensors[1].GetReading();
            textBox2.Text = reading.ToString();

            reading = sensors[2].GetReading();
            textBox3.Text = reading.ToString();

            reading = sensors[3].GetReading();
            textBox4.Text = reading.ToString();

            reading = sensors[4].GetReading();
            textBox5.Text = reading.ToString();

            this.Invalidate();
        }


    }
}
