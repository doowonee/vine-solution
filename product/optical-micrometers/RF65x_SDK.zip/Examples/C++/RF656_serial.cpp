#include <stdio.h>
#include "RF656Device.h"

int main(int argc, char* argv[])
{
	printf ("Probing RF656:\n");
	char *ComPortArg = NULL;
	if (argc > 1)
	{
		ComPortArg = argv[1];
	}
	RFDevice::Initialize();
	RFDevice::RF656Device *dev = new RFDevice::RF656Device();
	RFDevice::RFCOMHELLOANSWER hello;
	BOOL bConn = FALSE;
	if (ComPortArg == NULL)
	{
		printf ("OpenPort(\"COM2\")\n");
		bConn = dev->OpenPort("COM2",RFDevice::Baud230400);

	}
	else
	{
		printf ("OpenPort(\"%s\")\n", ComPortArg);
		bConn = dev->OpenPort(ComPortArg);
	}
	if (!bConn)
	{
		printf ("Failed\n");
	}
	else
	{
		for (int nAddr=1; nAddr<=127; nAddr++)
		{
			printf ("BindNetworkAddress(%d)\n", nAddr);
			dev->BindNetworkAddress(nAddr);
			printf ("HelloCmd()\n");
			if (!dev->HelloCmd())
			{
				printf ("Failed\n");
			}
			else
			{
				printf ("Detected!\n");
				dev->GetHelloAnswer(&hello);
				printf ("Type: %d\n"\
					"Modification: %d\n"\
					"SerialNum: %d\n"\
					"Range: %d\n"\
					"MaxDistance: %d\n",
					hello.bDeviceType,
					hello.bDeviceModificaton,
					hello.wDeviceSerial,
					hello.wDeviceRange,
					hello.wDeviceMaxDistance);
				printf ("StartStream()\n");

				dev->SetSynchType(0x01);
				if (0)//!dev->StartStream())
				{
					printf("Failed\n");
				}
				else
				{
					printf ("1000 x GetSingleMeasure(...)\n");
					//DWORD x = 0;
					USHORT x;//Changed by anchal
					for (int m=0; m<1000; m++)
					{
						if (!dev->GetSingleMeasure(&x))
						{
							printf ("Failed\n");
						}
						else
						{
							printf ("%u\t", x);
						}
					}
				}
				//printf("\n");
				printf ("StopStream()\n");
				if (!dev->StopStream())
				{
					printf("Failed\n");
				}
				nAddr = 255;//exit
			}
		}
	}
	printf ("ClosePort()\n");
	dev->ClosePort();
	delete dev;
	RFDevice::Cleanup();
	return 0;
}
