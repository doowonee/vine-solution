//#include <windows.h>
#include <stdio.h>
#include "RF711Device.h"
#include "RF256Device.h"

int Probe_RF256(int argc, char* argv[]);
int Probe_RF711(int argc, char* argv[]);

int main(int argc, char* argv[])
{
	Probe_RF256(argc, argv);
	//Probe_RF711(argc, argv);
}

int Probe_RF711(int argc, char* argv[])
{
	printf ("Probing RF711:\n");
	char *ComPortArg = NULL;
	if (argc > 1)
	{
		ComPortArg = argv[1];
	}
	RFDevice::Initialize();
	RFDevice::RF711Device *dev = new RFDevice::RF711Device();
	RFDevice::RFCOMHELLOANSWER hello;
	BOOL bConn = FALSE;
	if (ComPortArg == NULL)
	{
		printf ("OpenPort(\"/dev/ttyUSB0\")\n");
		bConn = dev->OpenPort("/dev/ttyUSB0");
	}
	else
	{
		printf ("OpenPort(\"%s\")\n", ComPortArg);
		bConn = dev->OpenPort(ComPortArg);
	}
	if (!bConn)
	{
		printf ("Failed\n");
	}
	else
	{
		for (int nAddr=1; nAddr<=127; nAddr++)
		{
			printf ("BindNetworkAddress(%d)\n", nAddr);
			dev->BindNetworkAddress(nAddr);
			printf ("HelloCmd()\n");
			if (!dev->HelloCmd())
			{
				printf ("Failed\n");
			}
			else
			{
				printf ("Detected!\n");
				dev->GetHelloAnswer(&hello);
				printf ("Type: %d\n"\
					"Modification: %d\n"\
					"SerialNum: %d\n"\
					"Range: %d\n"\
					"MaxDistance: %d\n",
					hello.bDeviceType,
					hello.bDeviceModificaton,
					hello.wDeviceSerial,
					hello.wDeviceRange,
					hello.wDeviceMaxDistance);
				printf ("20 x GetSingleMeasure(...)\n");
				INT32 x = 0, y = 0;
				for (int m=0; m<20; m++)
				{
				    //Sleep(10);
					if (!dev->GetSingleMeasure(&x, &y))
					{
						printf ("Failed\n");
					}
					else
					{
						printf ("Result: %d, %d\n", x, y);
						::Sleep(500);
					}
				}
				nAddr = 255;//exit
			}
		}
	}
	printf ("ClosePort()\n");
	dev->ClosePort();
	delete dev;
	RFDevice::Cleanup();
	return 0;
}

int Probe_RF256(int argc, char* argv[])
{
	printf ("Probing RF256:\n");
	char *ComPortArg = NULL;
	if (argc > 1)
	{
		ComPortArg = argv[1];
	}
	RFDevice::Initialize();
	RFDevice::RF256Device *dev = new RFDevice::RF256Device();
	RFDevice::RFCOMHELLOANSWER hello;
	BOOL bConn = FALSE;
	if (ComPortArg == NULL)
	{
		printf ("OpenPort(\"/dev/ttyUSB0\")\n");
		bConn = dev->OpenPort("/dev/ttyUSB0"/*, RFDevice::Baud460800*/);
	}
	else
	{
		printf ("OpenPort(\"%s\")\n", ComPortArg);
		bConn = dev->OpenPort(ComPortArg);
	}
	if (!bConn)
	{
		printf ("Failed\n");
	}
	else
	{
		for (int nAddr=1; nAddr<=127; nAddr++)
		{
			printf ("BindNetworkAddress(%d)\n", nAddr);
			dev->BindNetworkAddress(nAddr);
			printf ("HelloCmd()\n");
			if (!dev->HelloCmd())
			{
				printf ("Failed\n");
			}
			else
			{
				printf ("Detected!\n");
				dev->GetHelloAnswer(&hello);
				printf ("Type: %d\n"\
					"Modification: %d\n"\
					"SerialNum: %d\n"\
					"Range: %d\n"\
					"MaxDistance: %d\n",
					hello.bDeviceType,
					hello.bDeviceModificaton,
					hello.wDeviceSerial,
					hello.wDeviceRange,
					hello.wDeviceMaxDistance);
				printf ("StartStream()\n");
				if (!dev->StartStream())
				{
					printf("Failed\n");
				}
				else
				{
					printf ("1000 x GetStreamMeasure(...)\n");
					DWORD x = 0;
					for (int m=0; m<1000; m++)
					{
						if (!dev->GetStreamMeasure(&x))
						{
							printf ("Failed\t");
						}
						else
						{
							printf ("%u\t", x);
						}
					}
				}
				//printf("\n");
				printf ("StopStream()\n");
				if (!dev->StopStream())
				{
					printf("Failed\n");
				}
				nAddr = 255;//exit
			}
		}
	}
	printf ("ClosePort()\n");
	dev->ClosePort();
	delete dev;
	RFDevice::Cleanup();
	return 0;
}
