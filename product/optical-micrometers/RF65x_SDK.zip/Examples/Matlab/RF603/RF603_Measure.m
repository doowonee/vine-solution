clc;
clear;
if (libisloaded('RFDevice_proxy.dll'))
    hfile = fullfile('RFDevice_proxy.h');
    loadlibrary ('RFDevice_proxy',hfile);
end;

 libfunctionsview RFDevice_proxy


mc_p      =0;
dev_openport =1;
baud=0;
int32(mc_p);
int32(dev_openport);
uint32(baud);
baud=uint32(921600);

 Hello_Answer_struct = struct;
 
st_p_answer = libstruct('s_RFCOM_HELLO_ANSWER_', Hello_Answer_struct);
handle = uint32(0);
p = libpointer('voidPtrPtr',handle);
b =libpointer('int8Ptr');
m_p = 0;
uint16(m_p);

[mc_p] = calllib('RFDevice_proxy', 'RFDevice_Initialize');


[p]= calllib('RFDevice_proxy', 'CreateRF603Device');

  
[dev_openport,p,b] = calllib('RFDevice_proxy','RF603Device_OpenPort',p,int8('COM10'),baud);



dev_openport
[Msr_answer,p,m_p] = calllib('RFDevice_proxy', 'RF603Device_GetSingleMeasure', p, 1, m_p);
 
result = double(m_p)*50/16384
  
  
  
  
[clP_answer, p] = calllib('RFDevice_proxy', 'RF603Device_ClosePort', p);

 
 calllib('RFDevice_proxy', 'DisposeRF603Device',p);
 calllib('RFDevice_proxy', 'RFDevice_Cleanup');
