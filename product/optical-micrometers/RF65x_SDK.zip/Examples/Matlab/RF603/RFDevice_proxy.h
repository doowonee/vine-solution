#include "RFDevice.h"
#include "RFEthernetDetector.h"
#include "RFEthernetDevice.h"
#include "RFTypeDefs.h"
#include "RF625Device.h"
#include "RF625DDevice.h"
#include "RF603Device.h"





using namespace RFDevice;

#ifdef __cplusplus
extern "C" {
#endif


	/************************************************************************/
	/* Structures                                                           */
	/************************************************************************/

	typedef struct _UDP_DEVINFOBLOCK_PC {
		WORD				usDeviceType;
		BYTE				ucIP[4];
		BYTE				ucMAC[6];
		BYTE				ucInfo[256];
		_UDP_DEVINFOBLOCK_PC  *		pNext;
	}  UDP_DEVINFOBLOCK_PC, *LPUDP_DEVINFOBLOCK_PC;


	typedef struct _RFCOM_HELLO_ANSWER_
	{
		BYTE	bDeviceType;
		BYTE	bDeviceModificaton;
		WORD	wDeviceSerial;
		WORD	wDeviceMaxDistance;
		WORD	wDeviceRange;
	} RFCOMHELLOANSWER, *LPRFCOMHELLOANSWER;


	typedef struct _RF60x_PARAMS_
	{
		BOOL	LaserIsOn;
		BOOL	AnalogOutIsOn;
		BYTE	SampleAveragingControlByte;
		BYTE	NetAddress;
		DWORD	BaundRate;
		DWORD	AverageCount;
		DWORD	SamplingPeriod;
		DWORD	AccumulationTime;
		DWORD	ResultDelayTime;
		DWORD	ZeroPoint;
		DWORD	CanSpeed;
		DWORD	CanStdID;
		DWORD	CanExtID;
		BOOL	CanIdIsExt;
		BOOL	CanIsOn;
		BYTE	DestinationIP[4];
		BYTE	GateWayIP[4];
		BYTE	SubnetMask[4];
		BYTE	SourceIP[4];
		BOOL	EthIsOn;
		DWORD	BeginAnalogRange;
		DWORD	EndAnalogRange;
	} RF60xPARAMS, *LPRF60xPARAMS;

	typedef struct _RF60x_STREAM_VALUE_
	{
		WORD	wMeasure;
		BYTE	bStatus;
	} RF60xSTREAMVALUE, *LPRF60xSTREAMVALUE;


	typedef struct _RF60x_UDP_VALUE_
	{
		WORD	wMeasure;
		BYTE	bStatus;
	} RF60xUDPVALUE, *LPRF60xUDPVALUE;

	typedef struct _RF60x_UDP_PACKET_
	{
		RF60xUDPVALUE	rf60xValArray[168];
		WORD	wDeviceSerial;
		WORD	wDeviceBaseDistance;
		WORD	wDeviceMeasureRange;
		BYTE	bPackCount;
		BYTE	bPacketControlSumm;
	} RF60xUDPPACKET, *LPRF60xUDPPACKET;

	typedef struct _RF60xB_UDP_VALUE_
	{
		WORD	wMeasure;
		WORD	wExposition;
		BYTE	bStatus;
	} RF60xBUDPVALUE, *LPRF60xBUDPVALUE;

	typedef struct _RF60xB_UDP_PACKET_
	{
		RF60xBUDPVALUE	rf60xBValArray[100];
		WORD	wReserved;
		WORD	wReserved2;
		WORD	wDeviceSerial;
		WORD	wDeviceBaseDistance;
		WORD	wDeviceMeasureRange;
		BYTE	bPackCount;
		BYTE	bPacketControlSumm;
	} RF60xBUDPPACKET, *LPRF60xBUDPPACKET;


	typedef struct _RF60xHS_MEASURE_BLOCK_
	{
		DWORD	dwMeasure;
		BYTE	bStatus;
	} RF60xHSMEASUREBLOCK, *LPRF60xHSMEASUREBLOCK;


	typedef struct _RF60xHS_MEASURE_PACKET_
	{
		RF60xHSMEASUREBLOCK	rfbValues[100];
		WORD	wBlocksCount;
		WORD	wDeviceSerial;
		WORD	wDeviceBaseDistance;
		WORD	wDeviceMeasureRange;
		BYTE	bPacketCount;
		BYTE	bPacketControlSumm;
		WORD	wServiceInfo;

	} RF60xHSMEASUREPACKET, *LPRF60xHSMEASUREPACKET;



#pragma pack(push, 1)
	typedef struct _RF625DHS_PARAMETERS_
	{
		WORD	wConfigVersion;		// 0 : 2
		BYTE		ucLaserLevel;			// 2 : 1
		WORD	wExposureTime;		// 3 : 2
		BYTE		ucWindowLeft;			// 5 : 1
		BYTE		ucWindowWidth;			// 6 : 1
		BYTE		ucWindowTop;				// 7 : 1
		BYTE		ucWindowHeight;			// 8 : 1
		WORD	wExtSyncSignal;	// 9 : 2
		WORD	wExtSyncDivider;	// 11 : 2
		BYTE		ucTCPAddress[4];		// 13 : 4
		BYTE		ucTCPSubnetMask[4];		// 17 : 4
		BYTE		ucUDPAddress[4];		// 21 : 4
		WORD	wUDPPort;			// 25 : 2
		WORD	wUDPFrequency;		// 27 : 2
		WORD	wTCPPort;			// 29 : 2
		BYTE		ucAutoExposure;		// 31 : 1
		BYTE		ucPixelBrightnessThres;	// 32 : 1
		BYTE		ucDifBrightnessThres;	// 33 : 1
		BYTE		ucRawImageMode;			// 34 : 1
		BYTE		ucInterpolation;		// 35 : 1
		BYTE    	ucDHSEnable;			// 36 : 1
		BYTE		ucReserved[512-37];		// 0-padding
	} RF625DHS_PARAMETERS, *LPRF625DHS_PARAMETERS;
#pragma pack(pop)



	//////////////////////////////////////////////////////////////////////////

	/************************************************************************/
	/* Functions                                                            */
	/************************************************************************/

	BOOL RFDevice_Initialize();

	void  RFDevice_Cleanup();

	const char* RFDevice_GetVersionString(); 

	RF625Device*  CreateRF625Device();

	RF625Device*  CreateRF625Device_1( LPUDP_DEVINFOBLOCK_PC  lpDevBlock );

	void  DisposeRF625Device(RF625Device* rf);
	void  RF625Device_CloneParameters  (RF625Device* rf, RF625Device *  lpDev ) ;

	BOOL  RF625Device_Connect(RF625Device* rf);

	BOOL  RF625Device_Connect_1(RF625Device* rf, LPUDP_DEVINFOBLOCK_PC  lpDevBlock ) ;

	unsigned short  RF625Device_ConvertResultToPoints  (RF625Device* rf, 
		void IN *  lpResultBuffer,  
		float OUT *  lpPointsBuffer,  
		USHORT OUT *  lpCount);

	unsigned short  RF625Device_ConvertResultToPoints_1 (RF625Device* rf, 
		void IN *  lpResultBuffer,  
		float OUT *  lpPointsBuffer,  
		USHORT OUT *  lpCount  ) ;

	BOOL  RF625Device_Disconnect(RF625Device* rf);

	BOOL  RF625Device_FlushParams(RF625Device* rf, BOOL  bDefault = FALSE ) ;

	BYTE  RF625Device_GetAnalogueOutputNumberOfPoints   (RF625Device* rf) ;

	BYTE  RF625Device_GetAnalogueOutputPointHoldupTime    (RF625Device* rf) ;
	BOOL  RF625Device_GetAnalogueOutputSyncEdge     (RF625Device* rf) ;

	BOOL  RF625Device_GetAnalogueOutputSyncEnabled      (RF625Device* rf) ;
	BOOL  RF625Device_GetAnalogueOutputTTL_OUT0Level       (RF625Device* rf) ;

	WORD  RF625Device_GetBaseDistance(RF625Device* rf) ;

	BOOL  RF625Device_GetCapsAnalogueOutputByCurrent (RF625Device* rf) ;

	BOOL  RF625Device_GetCapsAnalogueOutputByVoltage  (RF625Device* rf) ;

	BOOL  RF625Device_GetCapsExternalMeasurementSync   (RF625Device* rf) ;

	BOOL  RF625Device_GetCapsExternalResultSync    (RF625Device* rf) ;

	BOOL  RF625Device_GetCapsLaserModulation     (RF625Device* rf) ;

	const LPUDP_DEVINFOBLOCK_PC  RF625Device_GetDevBlock(RF625Device* rf) ;
	const BYTE*  RF625Device_GetDeviceIPAddress (RF625Device* rf) ;

	WORD  RF625Device_GetExposureTime  (RF625Device* rf) ;

	BOOL  RF625Device_GetExternalMeasurementSyncEdge(RF625Device* rf) ;

	BOOL  RF625Device_GetExternalMeasurementSyncEnabled(RF625Device* rf) ;

	BOOL  RF625Device_GetExternalResultSyncEdge (RF625Device* rf) ;

	BOOL  RF625Device_GetExternalResultSyncEnabled(RF625Device* rf) ;

	BYTE  RF625Device_GetExternalSignalDivisor(RF625Device* rf);

	DWORD  RF625Device_GetFirmwareVersion(RF625Device* rf) ;
	const BYTE *  RF625Device_GetHostIPAddress (RF625Device* rf) ;

	WORD  RF625Device_GetHostPortNumber(RF625Device* rf) ;

	char*  RF625Device_GetHumanReadableDeviceIPAddress(RF625Device* rf) ;

	char*  RF625Device_GetHumanReadableHostIPAddress(RF625Device* rf);

	char*  RF625Device_GetHumanReadableNetworkMask(RF625Device* rf) ;

	BOOL  RF625Device_GetImage(RF625Device* rf, void *  lpBuffer ) ;

	BYTE  RF625Device_GetLaserLevel(RF625Device* rf) ;

	BYTE  RF625Device_GetLeftBoundary (RF625Device* rf) ;

	BYTE  RF625Device_GetMeasurementDelay(RF625Device* rf) 

		WORD  RF625Device_GetMeasurementRangeXEMR(RF625Device* rf) ;

	WORD  RF625Device_GetMeasurementRangeXSMR(RF625Device* rf) ;

	WORD  RF625Device_GetMeasurementRangeZ(RF625Device* rf) ;

	const BYTE *  RF625Device_GetNetworkMask(RF625Device* rf) ;

	unsigned short  RF625Device_GetNormalizedResult(RF625Device* rf,
		float OUT *  lpPointsBuffer,
		USHORT OUT *  lpCount);


	BOOL  RF625Device_GetResult(RF625Device* rf, void *  lpBuffer, BOOL bOldMode = FALSE) ;

	short RF625Device_GetResultInclinationAngle(RF625Device* rf) ;

	short RF625Device_GetRotationAngle(RF625Device* rf) ;

	DWORD RF625Device_GetSerialNumber (RF625Device* rf) ;

	WORD  RF625Device_GetSignalProcessingTime(RF625Device* rf) ;

	BYTE  RF625Device_GetUDPFrequency(RF625Device* rf) ;

	BYTE  RF625Device_GetUpperBoundary (RF625Device* rf) ;

	BYTE  RF625Device_GetWindowHeight(RF625Device* rf) ;

	BYTE  RF625Device_GetWindowWidth(RF625Device* rf) ;

	BOOL  RF625Device_PingTest(RF625Device* rf) ;

	BOOL  RF625Device_ReadParams(RF625Device* rf) ;

	BOOL  RF625Device_WriteParams(RF625Device* rf) ;

	BOOL  RF625Device_SetAnalogueOutputNumberOfPoints(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetAnalogueOutputPointHoldupTime(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetAnalogueOutputSyncEdge(RF625Device* rf,  BOOL  bValue  ) ;

	BOOL  RF625Device_SetAnalogueOutputSyncEnabled(RF625Device* rf, BOOL  bValue ) ;
	BOOL  RF625Device_SetAnalogueOutputTTL_OUT0Level(RF625Device* rf, BOOL  bValue ) ;

	BOOL  RF625Device_SetDeviceIPAddress(RF625Device* rf, BYTE  ucValue[4] );

	BOOL  RF625Device_SetExposureTime(RF625Device* rf, WORD  wValue ) ;

	BOOL  RF625Device_SetExternalMeasurementSyncEdge(RF625Device* rf, BOOL  bValue ) ;

	BOOL  RF625Device_SetExternalMeasurementSyncEnabled(RF625Device* rf, BOOL  bValue ) ;

	BOOL  RF625Device_SetExternalResultSyncEdge(RF625Device* rf, BOOL  bValue ) ;

	BOOL  RF625Device_SetExternalResultSyncEnabled(RF625Device* rf, BOOL  bValue ) ;

	BOOL  RF625Device_SetExternalSignalDivisor(RF625Device* rf, BYTE  ucValue );

	BOOL  RF625Device_SetHostIPAddress(RF625Device* rf, BYTE  ucValue[4] ) ;

	BOOL  RF625Device_SetHostPortNumber(RF625Device* rf, WORD  wValue ) ;

	BOOL  RF625Device_SetLaserLevel(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetLeftBoundary(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetMeasurementDelay(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetNetworkMask(RF625Device* rf, BYTE  ucValue[4] ) ;

	BOOL  RF625Device_SetRotationAngle(RF625Device* rf, short  sValue ) ;

	BOOL  RF625Device_SetSignalProcessingTime (RF625Device* rf, WORD  wValue  ) ;

	BOOL  RF625Device_SetUDPFrequency(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetUpperBoundary (RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetWindowHeight(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_SetWindowWidth(RF625Device* rf, BYTE  ucValue ) ;

	BOOL  RF625Device_UDPConnect(RF625Device* rf,
		USHORT  usUDPPort,  
		LPCSTR  szLocalIPAddress = NULL);

	BOOL  RF625Device_UDPDisconnect(RF625Device* rf) ;

	unsigned short  RF625Device_UDPGetNormalizedResult(RF625Device* rf,
		DWORD OUT *  lpPointsBuffer,  
		USHORT OUT *  lpCount)
	{
		return rf->UDPGetNormalizedResult (lpPointsBuffer, lpCount);
	}

	unsigned short  RF625Device_UDPGetNormalizedResult_1(RF625Device* rf,
		float OUT *  lpPointsBuffer,  
		USHORT OUT *  lpCount);
	BOOL    RF625Device_UDPGetResult(RF625Device* rf, void *  lpBuffer, BOOL bOldMode = FALSE ) ;

	BOOL    RF625Device_UDPPacketCounter (RF625Device* rf, void *  lpBuffer ) ;

	size_t  RF625Device_ImageBufferSize();

	size_t  RF625Device_ProfileBufferSize();

	size_t  RF625Device_ProfileValuesCount();
	//NewAfter620

	bool  RF625Device_Reboot(RF625Device* rf);

	bool  RF625Device_PowerOff(RF625Device* rf);

	bool  RF625Device_SetDevicePortNumber(RF625Device* rf, WORD Port);

	WORD  RF625Device_GetDevicePortNumber(RF625Device* rf);

	bool  RF625Device_SetPixelBrightnessThreshold(RF625Device* rf, BYTE Value);

	BYTE  RF625Device_GetPixelBrightnessThreshold(RF625Device* rf);

	bool  RF625Device_SetAutoExposureMode(RF625Device* rf, BYTE Mode);

	BYTE  RF625Device_GetAutoExposureMode(RF625Device* rf);

	bool  RF625Device_SetEnableLegacyMode(RF625Device* rf, bool Enable);

	bool  RF625Device_GetEnabledLegacyMode(RF625Device* rf);

	bool  RF625Device_SetEnableRawImageMode(RF625Device* rf, bool Enable);

	bool  RF625Device_GetEnabledRawImageMode(RF625Device* rf);

	bool  RF625Device_SetEnableInterpolation(RF625Device* rf, bool Enable);

	bool  RF625Device_GetEnabledInterpolation(RF625Device* rf);

	bool  RF625Device_GetAutoExposure(RF625Device* rf, LPWORD usValue);


	RFEthernetDetector*  CreateRFEthernetDetector()	;

	void  DisposeRFEtnernetDetector(RFEthernetDetector* rf);

	int  RFEthernetDetector_Search(RFEthernetDetector* rf, USHORT type, int timeout)	;

	void RFEthernetDetector_Clear(RFEthernetDetector* rf)	;

	int  RFEthernetDetector_GetSize(RFEthernetDetector* rf)	;

	LPUDP_DEVINFOBLOCK_PC  RFEthernetDetector_GetDevBlock(RFEthernetDetector* rf, const int index);




	//////////////////////////////////////////////////////////////////////////
	// RF625DHSDevice
	//////////////////////////////////////////////////////////////////////////

	RF625DDevice*  CreateRF625DDevice(const DWORD dwOwnerPID = 0);



	RF625DDevice*  CreateRF625DDevice_1(LPUDP_DEVINFOBLOCK_PC lpDevBlock, const DWORD dwOwnerPID = 0);

	void  DisposeRF625DDevice(RF625DDevice* rf)

	BOOL  RF625DDevice_Disconnect(RF625DDevice* rf)

	BOOL  RF625DDevice_ReadParams(RF625DDevice* rf) 

	BOOL  RF625DDevice_WriteParams(RF625DDevice* rf) 

	BOOL  RF625DDevice_GetResult(RF625DDevice* rf,void* lpBuffer) 

	BOOL  RF625DDevice_GetExtends(RF625DDevice* rf,void* lpBuffer) 

	BOOL  RF625DDevice_GetImage(RF625DDevice* rf,void* lpBuffer) 

    BOOL  RF625DDevice_Connect(RF625DDevice* rf)
	
	BOOL  RF625DDevice_Connect_1(RF625DDevice* rf, LPUDP_DEVINFOBLOCK_PC  lpDevBlock ) 

    USHORT  RF625DDevice_ConvertResultToPoints(RF625DDevice* rf, void IN *lpResultBuffer, float OUT *lpPointsBuffer, USHORT OUT *lpCount, USHORT *lpMeasureCnt = NULL, USHORT *lpPacketCnt = NULL, BOOL bChecksumCheck = FALSE)

	USHORT  RF625DDevice_GetNormalizedResult(RF625DDevice* rf,float OUT *lpPointsBuffer, USHORT OUT *lpCount)

	USHORT  RF625DDevice_UDPGetNormalizedResult(RF625DDevice* rf,float OUT *lpPointsBuffer, USHORT OUT *lpCount)

    WORD  RF625DDevice_GetUDPFrequency(RF625DDevice* rf)
		
	BOOL  RF625DDevice_SetUDPFrequency(RF625DDevice* rf,WORD wValue)
	
	WORD  RF625DDevice_GetExternalSignalDivisor(RF625DDevice* rf)
	
	BOOL  RF625DDevice_SetExternalSignalDivisor(RF625DDevice* rf,WORD wValue)
	
    WORD  RF625DDevice_GetTCPPortNumber(RF625DDevice* rf)
    
	BOOL  RF625DDevice_SetTCPPortNumber(RF625DDevice* rf,WORD wValue
	
	BOOL  RF625DDevice_GetEnableDHS(RF625DDevice* rf)
     
	BOOL  RF625DDevice_SetEnableDHS(RF625DDevice* rf,BOOL bEnable)
	
    BYTE  RF625DDevice_GetDifBrightness(RF625DDevice* rf)
     
    BOOL  RF625DDevice_SetDifBrightness(RF625DDevice* rf,BYTE ucValue)

    BOOL  RF625DDevice_UDPConnect(RF625DDevice* rf,		USHORT  usUDPPort, 	LPCSTR  szLocalIPAddress = NULL)
	
	BOOL RF625DDevice_UDPDisconnect(RF625DDevice* rf) 

    
    
    


		//////////////////////////////////////////////////////////////////////////
		// RF603Device
		//////////////////////////////////////////////////////////////////////////


		/************************************************************************/
		/* Structures                                                           */
		/************************************************************************/






		//////////////////////////////////////////////////////////////////////////

		/************************************************************************/
		/* Functions                                                            */
		/************************************************************************/   



		RF603Device*  CreateRF603Device();

	void  DisposeRF603Device(RF603Device* rf);


	BOOL  RF603Device_EthernetGetStreamMeasure(RF603Device* rf, LPRF60xUDPPACKET packet);

	BOOL  RF603Device_EthernetGetNormalizedStreamMeasure(RF603Device* rf, float* OUT lpValues);

	BOOL  RF603Device_SetCanSpeed(RF603Device* rf, DWORD val);

	BOOL  RF603Device_SetCanStdID(RF603Device* rf, DWORD val);

	BOOL  RF603Device_SetCanExtID(RF603Device* rf, DWORD val);

	BOOL  RF603Device_SetCanIdTypeToExt(RF603Device* rf);

	BOOL  RF603Device_SetCanIdTypeToStd(RF603Device* rf);

	BOOL  RF603Device_EnableCan(RF603Device* rf, BOOL bEnable = TRUE);

	BOOL  RF603Device_SetDestinationIP(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetDestinationIP_1(RF603Device* rf, BYTE ucValue[4]);

	BOOL  RF603Device_SetGatewayIP(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetGatewayIP_1(RF603Device* rf, BYTE ucValue[4]);

	BOOL  RF603Device_SetSubnetMask(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetSubnetMask_1(RF603Device* rf, BYTE ucValue[4]);

	BOOL  RF603Device_SetSourceIP(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetSourceIP_1(RF603Device* rf, BYTE ucValue[4]);

	BOOL  RF603Device_EnableEth(RF603Device* rf, BOOL bEnable = TRUE);

	DWORD  RF603Device_GetCanSpeed(RF603Device* rf);

	DWORD  RF603Device_GetCanStdID(RF603Device* rf);

	DWORD  RF603Device_GetCanExtID(RF603Device* rf);

	BOOL  RF603Device_GetCanId(RF603Device* rf);

	BOOL  RF603Device_GetCanState(RF603Device* rf);

	BYTE*  RF603Device_GetDestinationIP(RF603Device* rf);

	char*  RF603Device_GetHumanReadableDestinationIP(RF603Device* rf);

	BYTE*  RF603Device_GetGatewayIP(RF603Device* rf);

	char*  RF603Device_GetHumanReadableGatewayIP(RF603Device* rf);

	BYTE*  RF603Device_GetSubnetMask(RF603Device* rf);

	char*  RF603Device_GetHumanReadableSubnetMask(RF603Device* rf);

	BYTE*  RF603Device_GetSourceIP(RF603Device* rf);

	char*  RF603Device_GetHumanReadableSourceIP(RF603Device* rf);

	BOOL  RF603Device_GetEthState(RF603Device* rf);

	//////////////////////////////////////////////////////////////////////////
	// RF60xDevice
	//////////////////////////////////////////////////////////////////////////

	void	BindNetworkAddress(BYTE ucAddress);

	BOOL  RF603Device_GetTimeouts(RF603Device* rf, 
		LPDWORD lpdwReadIntervalTimeout, LPDWORD lpdwReadTotalTimeoutMultiplier, 
		LPDWORD lpdwReadTotalTimeoutConstant, LPDWORD lpdwWriteTotalTimeoutMultiplier, 
		LPDWORD lpdwWriteTotalTimeoutConstant);

	BOOL  RF603Device_SetTimeouts(RF603Device* rf, 
		DWORD dwReadIntervalTimeout, DWORD dwReadTotalTimeoutMultiplier, 
		DWORD dwReadTotalTimeoutConstant, DWORD dwWriteTotalTimeoutMultiplier, 
		DWORD dwWriteTotalTimeoutConstant);

	/* BOOL  RF603Device_HelloCmd_1(RF603Device* rf, BYTE bAddress, LPRF60xHELLOANSWER lprfHelloAnswer)
	{
	return rf->HelloCmd(bAddress, lprfHelloAnswer);
	}*/

	BOOL  RF603Device_HelloCmd(RF603Device* rf);

	BOOL  RF603Device_GetStreamMeasures(RF603Device* rf, 
		LPRF60xSTREAMVALUE lpusStreamValues, DWORD dwMeasuresCount, 
		LPDWORD lpdwReadedMeasuresCount, LPDWORD lpdwBrokenPacketsCount);

	BOOL  RF603Device_GetSingleMeasure(RF603Device* rf,LPWORD lpwValue);

	BOOL  RF603Device_EnableSensor(RF603Device* rf, BOOL bEnable = TRUE);

	BOOL  RF603Device_EnableAnalogOut(RF603Device* rf, BOOL bEnable = TRUE);
	BOOL  RF603Device_SetSampleAveraging(RF603Device* rf, BYTE ucValue);

	BOOL  RF603Device_SetAverageModeByQuantity(RF603Device* rf);

	BOOL  RF603Device_SetAverageModeByTime(RF603Device* rf);

	BOOL  RF603Device_SetCANModeByRequest(RF603Device* rf);

	BOOL  RF603Device_SetCANModeByClk(RF603Device* rf);

	BOOL  RF603Device_SetLogicOutModeToRangeOverflow(RF603Device* rf);

	BOOL  RF603Device_SetLogicOutModeToMutualSynchronization(RF603Device* rf);

	BOOL  RF603Device_SetLogicOutModeToResZeroing(RF603Device* rf);

	BOOL  RF603Device_SetLogicOutModeToLaserPower(RF603Device* rf);

	BOOL  RF603Device_SetAnalogOutModeToFrameMode(RF603Device* rf);

	BOOL  RF603Device_SetAnalogOutModeToFullMode(RF603Device* rf);

	BOOL  RF603Device_SetSampleModeToTime(RF603Device* rf);

	BOOL  RF603Device_SetSampleModeToClk(RF603Device* rf);

	BOOL  RF603Device_SetNetworkAddress(RF603Device* rf, BYTE ucValue);

	BOOL  RF603Device_SetBaundRate(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetAverageCount(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetSamplingPeriod(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetAccumulationTime(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetBeginAnalogRange(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetEndAnalogRange(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetResultDelayTime(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_SetZeroPointValue(RF603Device* rf, DWORD dwValue);

	BOOL  RF603Device_GetPowerState(RF603Device* rf);

	BOOL  RF603Device_GetAnalogOut(RF603Device* rf);

	BOOL  RF603Device_GetSampleAveraging(RF603Device* rf);

	BOOL  RF603Device_IsAverageModeByTime(RF603Device* rf);

	BOOL  RF603Device_IsCANModeBySynch(RF603Device* rf);

	BYTE  RF603Device_GetLogicOutMode(RF603Device* rf);

	BOOL  RF603Device_IsAnalogOutModeFull(RF603Device* rf);

	BOOL  RF603Device_IsSampleModeClk(RF603Device* rf);

	BYTE  RF603Device_GetNetworkAddress(RF603Device* rf);

	DWORD  RF603Device_GetBaundRate(RF603Device* rf);

	DWORD  RF603Device_GetAverageCount(RF603Device* rf);

	DWORD  RF603Device_GetSamplingPeriod(RF603Device* rf);

	DWORD  RF603Device_GetAccumulationTime(RF603Device* rf);

	DWORD  RF603Device_GetBeginAnalogRange(RF603Device* rf);

	DWORD  RF603Device_GetEndAnalogRange(RF603Device* rf);

	DWORD  RF603Device_GetResultDelayTime(RF603Device* rf);


	DWORD  RF603Device_GetZeroPointValue(RF603Device* rf);

	LPRF60xPARAMS  RF603Device_GetParams(RF603Device* rf);

	//////////////////////////////////////////////////////////////////////////
	// RFComDevice
	//////////////////////////////////////////////////////////////////////////

	void  RF603Device_BindNetworkAddress(RF603Device* rf, BYTE ucAddress);

	BOOL  RF603Device_OpenPort(RF603Device* rf, LPCSTR lpPort_Name, DWORD dwSpeed);

	BOOL  RF603Device_ClosePort(RF603Device* rf);

	BOOL  RF603Device_ReadParameter(RF603Device* rf, BYTE bAddress, WORD wParameter, DWORD* lpdwValue);

	BOOL  RF603Device_WriteParameter(RF603Device* rf, BYTE bAddress, WORD wParameter, DWORD dwValue);

	BOOL  RF603Device_ReadCustomParameter(RF603Device* rf, BYTE bAddress, BYTE bParameterAddress, BYTE bParameterSize, void* lpValue);

	BOOL  RF603Device_WriteCustomParameter(RF603Device* rf, BYTE bAddress, BYTE bParameterAddress, BYTE bParameterSize, void* lpValue);

	BOOL  RF603Device_FlushToFlash(RF603Device* rf, BYTE bAddress);

	BOOL  RF603Device_RestoreFromFlash(RF603Device* rf, BYTE bAddress);

	BOOL  RF603Device_LockResult(RF603Device* rf, BYTE bAddress);

	BOOL  RF603Device_Measure(RF603Device* rf,BYTE bAddress, BYTE* lpucBuffer, int nBufLength = 2);

	BOOL  RF603Device_StartStream(RF603Device* rf, BYTE bAddress);

	BOOL  RF603Device_StopStream(RF603Device* rf, BYTE bAddress);

	BOOL  RF603Device_GetStreamMeasure(RF603Device* rf, USHORT* lpusValue);

	BOOL  RF603Device_CustomCmd(RF603Device* rf, char * pcInData, DWORD dwInSize, char * pcOutData, DWORD * pdwOutSize);

	int  RF603Device_GetPortHandle(RF603Device* rf);

	BOOL  RF603Device_ValidateData(LPBYTE lpucData, const int nDataLength);

	BOOL  RF603Device_EthernetOpenPort(RF603Device* rf);

	BOOL  RF603Device_EthernetSetTimeout(RF603Device* rf, DWORD dwTimeout);

	BOOL  RF603Device_EthernetClosePort(RF603Device* rf);


#ifdef __cplusplus
}
#endif