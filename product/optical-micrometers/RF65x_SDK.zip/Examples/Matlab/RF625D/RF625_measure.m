clc;
clear;
if (~libisloaded('RFDevice_proxy'))
    hfile = fullfile('RFDevice_proxy.h');
    loadlibrary ('RFDevice_proxy',hfile);
end;

%libfunctionsview RFDevice_proxy

p = libpointer('voidPtr');
devblockHandle=libpointer('voidPtr');
rf625DeviceHandle=libpointer('voidPtr');
f =libpointer('singlePtr');
%f_=libpointer('uint16Ptr');


mc_p         =0;
dev_type     =0;
dev_count    =0;
connect      =0;
res          =0;


int32(mc_p);
int32(connect);
int32(dev_count);
uint16(res);

[mc_p] = calllib('RFDevice_proxy', 'RFDevice_Initialize');

% UDP_DEVINFOBLOCK_PC_struct = struct;
% st_p = libstruct('s_UDP_DEVINFOBLOCK_PCPtr', UDP_DEVINFOBLOCK_PC_struct);



[p]=  calllib('RFDevice_proxy', 'CreateRFEthernetDetector');
[dev_count,voidPtr]= calllib('RFDevice_proxy', 'RFEthernetDetector_Search',p,625,2);
if(dev_count~=0)
 disp('Found');
 dev_count;
end;

[devblockHandle]    =calllib('RFDevice_proxy', 'RFEthernetDetector_GetDevBlock',p,0);
[rf625DeviceHandle] =calllib('RFDevice_proxy', 'CreateRF625Device_1',devblockHandle);
[connect]           =calllib('RFDevice_proxy', 'RF625Device_Connect',rf625DeviceHandle);

if(connect~=0)
 disp('Connected');
 dev_count;
 
else 
     disp('Unable to connect');
end;
  
 [pValuesCount]                        =calllib ('RFDevice_proxy', 'RF625Device_ProfileValuesCount');

while 1==1
x = zeros(1,10776);
 [res,rf625DeviceHandle,x,f_]          =calllib('RFDevice_proxy', 'RF625Device_GetNormalizedResult',rf625DeviceHandle,x,pValuesCount);

if(res~=0)
% disp('data');
 dev_count;
 x(~x)=[];
 x
else 
     disp('error');
end;
pause(1);
end;


calllib('RFDevice_proxy', 'RF625Device_Disconnect',rf625DeviceHandle);
calllib('RFDevice_proxy', 'DisposeRF625Device',rf625DeviceHandle);
calllib('RFDevice_proxy', 'DisposeRFEtnernetDetector',p);
calllib('RFDevice_proxy', 'RFDevice_Cleanup');

