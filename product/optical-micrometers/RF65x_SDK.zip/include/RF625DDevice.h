#ifndef RF625DDevice

#define RF625DDevice RF625Device
#include "RF625Device.h"

#pragma message ("warning: RF625DDevice class name is only used for compatibility with legacy programs. Use RF625Device class name instead.")

#endif
