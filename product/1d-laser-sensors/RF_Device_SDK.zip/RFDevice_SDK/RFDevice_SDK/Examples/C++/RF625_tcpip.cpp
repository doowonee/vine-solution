/************************************************************************/
/*																		*/
/*	RF625_tcpip.cpp														*/
/*																		*/
/*	RFDevice sample program												*/
/*																		*/
/*	 Demonstrate how to:												*/
/*	 - Search RF625 over network										*/
/*	 - Connect(TCP) to the number of RF625								*/
/*	 - Read measurements(TCP) from number of RF625						*/
/*	 - Disconnect(TCP) the number of RF625								*/
/*																		*/
/************************************************************************/




#include <iostream>
#include <vector>
#include "RF625Device.h"
#include "RFEthernetDetector.h"

using namespace std;
#define GETRESULT_ERROR_VALUE ((USHORT)0xffff)
#define MIN(a,b) (a<b ? a : b)
#define MEASURES_TO_DO 5
#define VALUES_TO_PRINT 4

int main(int argc, char *argv[])
{
	int nRF625;
	int i, j, k;
	vector<RFDevice::RF625Device *> vRF625;
	//	Buffer for maximal quantity of result points (X,Z * 1280 pts)
	float pPointsBuffer[RFDevice::RF625Device::ProfileValuesCount];
	USHORT nPoints;

	//	Initialize RFDevice
	RFDevice::Initialize();

	//	Create RFLanDetector object
	RFDevice::RFEthernetDetector ld;

	//	Execute search for device type 625 (RF625) for 3 seconds
	//	RF625 sends UDP information packet each 2 seconds so 3 seconds must be enough to catch all of them
	cout << "Searching..." << endl;
	nRF625 = ld.Search(625, 3);

	//	Now nRF625 holds a quantity of detected RF625
	cout << "Found " << nRF625 << " of RF625" << endl;

	//	Create list of RF625Device objects for all found devices
	for (i=0; i<nRF625; i++)
	{
		RFDevice::RF625Device *p = new RFDevice::RF625Device(ld[i]);
		if (p)
		{
			vRF625.push_back(p);
		}
		else
		{
			cout << "Failed to construct RF625Device #" << i << endl;
		}
	}
	nRF625 = vRF625.size();

	//	Sequentially connect to each RF625
	for (i=0; i<nRF625; i++)
	{
		if (FALSE == vRF625[i]->Connect())
		{
			cout << "Failed to Connect(TCP) to RF625Device #" << i << endl;
		}
		else
		{
			cout << "Connected(TCP) to RF625Device #" << i << endl;
		}
	}

	//	Get MEASURES_TO_DO measures from each RF625
	for (k=0; k<MEASURES_TO_DO; k++)
	{
		for (i=0; i<nRF625; i++)
		{
			if (GETRESULT_ERROR_VALUE == vRF625[i]->GetNormalizedResult(pPointsBuffer, &nPoints))
			{
				cout << "Failed to read measure from RF625Device #" << i << endl;
			}
			else
			{
				//	Print first VALUES_TO_PRINT values
				cout << "RF625Device #" << i << ": " << nPoints << " points:" << endl << "  {";
				for (j=0; j<MIN(VALUES_TO_PRINT,nPoints); j++)
				{
					cout << pPointsBuffer[j*2] << "," << pPointsBuffer[j*2+1];
					if (j<MIN(VALUES_TO_PRINT-1,nPoints-1)) cout << "; ";
				}
				cout << "...}" << endl;
			}
		}
		if (nRF625 > 0) ::Sleep(1000);
	}

	//	Sequentially disconnect each RF625
	for (i=0; i<nRF625; i++)
	{
		if (FALSE == vRF625[i]->Disconnect())
		{
			cout << "Failed to Disconnect(TCP) RF625Device #" << i << endl;
		}
		else
		{
			cout << "Disconnected(TCP) RF625Device #" << i << endl;
		}
	}

	//	Release memory
	while (!vRF625.empty())
	{
		RFDevice::RF625Device *p = vRF625.back();
		if (p) delete p;
		vRF625.pop_back();
	}

	//	Cleanup RFDevice
	RFDevice::Cleanup();

	return 0;
}

